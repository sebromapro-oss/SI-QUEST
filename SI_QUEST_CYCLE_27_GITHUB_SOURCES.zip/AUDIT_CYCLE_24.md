# SI QUEST — Cycle 24 : Spring Guard et validation des calculs intermédiaires
**Date : 25 octobre 2026.** Reprise de la dernière livraison réelle accessible, **`SI_QUEST_CYCLE_23_20261025.zip`**, SHA-256 `5ee25ab1c3adb1a688c57efa1f59cc2b8b0131b3a40ac64cdcf5f5e65ed22ce1`. Extraction et modifications ciblées ; aucun redémarrage à zéro ; aucun déploiement.

## Développement effectif

- **Sixième niveau indépendant** : `spring-01` dans **SI-11 — Résistance des matériaux et structures**, « Spring Guard — Protéger le support de machine ». Nouvelle mécanique : l'élève choisit la raideur d'un ressort et lance un chargement quasi statique. Le ressort se comprime selon le calcul ; la butée reprend réellement le reliquat de la force si la course maximale est atteinte. Un essai faux n'est pas bloqué.
- **Modèle physique autonome** : `SIPhysics.springStop` dans `src/physics.js` ; aucun DOM dans le calcul. Conversion N/mm → N/m, loi de Hooke, compression libre/réelle, équilibre des forces, énergie élastique. La cinématique du dessin est recalculée à chaque trame à partir de la force appliquée instantanée `F(t) = 1200 × progression` (rampe quasi statique, **pas** simulation dynamique d'un choc).
- **Contraintes fonctionnelles distinctes** : compression utile **26–31 mm**, course de butée **32 mm**, réaction de butée **0 N**, énergie stockée **≤ 17 J**, raideur choisie parmi **25, 30, 35, 40, 45, 50, 60 N/mm**. La seule raideur proposée conforme est **45 N/mm**.
- **Correction de progression Gravity Run** : la trajectoire physiquement correcte **ne suffit plus** à attribuer les étoiles si les calculs d'accélération, de résultante et de traction ne respectent pas les tolérances annoncées. Le retour distingue trajectoire conforme et calculs à reprendre. Les tolérances existantes (±0,075 m/s² ; ±18 N ; ±22 N) sont conservées.
- **Accueil et carte non refondus** : mêmes quatre îles interactives ; la nouvelle mission apparaît dans les cartes et dans l'univers SI-11. Seuls les textes de compteur devenus inexacts sont mis à jour dynamiquement (6 niveaux, 11 univers sans niveau jouable). Pas de badge ajouté ; les records sont fondés sur les victoires effectives. Le service worker passe au cache `siquest-cycle24-20261025`.

## Contrôle scientifique indépendant — charge F = 1 200 N

`k_SI = 1000 k_(N/mm)` ; `x_libre = F/k_SI` ; `x_réel = min(x_libre, 0,032 m)` ; `F_ressort = k_SI x_réel` ; `F_butée = max(0, F − F_ressort)` ; `E = ½ k_SI x_réel²`.

| Raideur | Compression libre | Compression réelle | Force de butée | Énergie stockée | Verdict |
|---|---:|---:|---:|---:|---|
| 25 N/mm | 48 mm | 32 mm | 400 N | 12,80 J | Butée chargée |
| 35 N/mm | 34,286 mm | 32 mm | 80 N | 17,92 J | Butée chargée et énergie excessive |
| 40 N/mm | 30 mm | 30 mm | 0 N | 18,00 J | Énergie excessive (seuil 17 J) |
| **45 N/mm** | **26,667 mm** | **26,667 mm** | **0 N** | **16,00 J** | **Conforme** |
| 50 N/mm | 24 mm | 24 mm | 0 N | 14,40 J | Compression insuffisante |

**Validation croisée :** à 35 N/mm, `F_ressort = 35 000 × 0,032 = 1 120 N`, `F_butée = 1 200 − 1 120 = 80 N` ; `E = ½ × 35 000 × (0,032)² = 17,92 J`. À 45 N/mm, `x = 1 200 / 45 000 = 0,0266667 m` et `E = ½ × 1 200 × 0,0266667 = 16 J`. Le test vérifie aussi pour chaque raideur `F_ressort + F_butée = F` et `E = ½ F_ressort x`.

**Hypothèses et limites :** ressort idéal linéaire, compression axiale, sans précharge, flambement, hystérésis, fatigue ni masse propre. Butée supposée rigide ; pas de choc ni d'amortissement ; énergie potentielle élastique sans modèle de restitution dynamique. Les seuils de compression et d'énergie sont les critères **du scénario pédagogique**, pas une norme constructeur. Les illustrations sont schématiques.

## Preuves exécutées et fichiers

| Contrôle | Résultat mesuré | Preuve |
|---|---|---|
| Node `--test` : anciens modèles + nouveau ressort + sauvegarde | **54/54 tests réussis** | `tests/cycle24-node-tap.txt` |
| Liens locaux, icônes, syntaxe JavaScript | **OK** | `tests/cycle24-static.txt` |
| Chromium headless, DOM injecté, 1440 × 900 | **6/6 victoires, 6/6 essais faux**, 0 erreur JS | `tests/cycle24-browser-1440.json` |
| Chromium headless, DOM injecté, 390 × 844 | **6/6 victoires, 6/6 essais faux**, 0 erreur JS | `tests/cycle24-browser-390.json` |
| Chromium headless, DOM injecté, 320 × 640 | **6/6 victoires, 6/6 essais faux**, 0 erreur JS | `tests/cycle24-browser-320.json` |
| Contrôles additionnels DOM | Butée, énergie, raideur non proposée, pression arrondie, surpression, calculs Gravity Run refusés si faux, sauvegarde 6/6 | Trois rapports DOM ci-dessus |
| Animations Chromium sans réduction des mouvements | **6/6 niveaux avec trames distinctes** | `tests/cycle24-motion-results.json` |
| Transport HTTP local des ressources + manifeste + version de cache | **12/12 réponses 200** | `tests/cycle24-http-results.json` |
| Capture mobile simulé (390 px) | Avant/après essai, examinées visuellement | `tests/cycle24-mobile-spring.png`, `tests/cycle24-mobile-spring-win.png` |

**Méthodes à ne pas confondre :** les essais DOM et les animations utilisent **Chromium headless avec injection des ressources** ; la navigation HTTP de Chromium est bloquée par la politique de l'environnement et n'est pas validée. Le test HTTP passe par un client Python indépendant ; il **ne valide pas** l'installation PWA, le service worker effectif, le hors-ligne ou la navigation HTTPS. **Aucun essai sur téléphone Android/iPhone, tablette, Windows ou Mac physiques ; aucun test manuel TalkBack, VoiceOver, NVDA ou clavier sur matériel ; aucune certification WCAG/RGAA.** Les contrôles clavier dans Chromium automatisé ne remplacent pas ces essais.

## Comptage honnête et réserves

- **17 univers catalogués**, dont **6 contiennent au moins un niveau jouable** ; **6 sous-savoirs développés / 249** ; **6 niveaux indépendants jouables et testés automatiquement / 996** ; **+1 niveau** dans ce cycle ; **0 niveau factice** ; **0 badge ajouté** ; **0 publication GitHub**.
- **243 sous-savoirs** et **990 niveaux** restent à développer. Les six niveaux ne sont pas réceptionnés sur matériel réel.
- Les modèles existants restent simplifiés et leurs réserves des cycles 22 et 23 demeurent. L'animation du ressort a fait l'objet de tests d'évolution des trames, **pas** d'une validation visuelle indépendante exhaustive à chaque instant. Les lecteurs d'écran et la PWA nécessitent une recette réelle.
- Les missions finales intégratrices (plusieurs sous-systèmes et décision professionnelle de remise en service) sont **à développer** ; elles ne sont pas comptées parmi les six niveaux.
- La recette approfondie reste visée **du 22 au 28 novembre 2026** et se poursuivra si nécessaire. Aucune publication GitHub sans validation.

### Reproduction

```sh
cd SI_QUEST
node --test tests/*.test.cjs
python tests/check_static.py
python tests/cycle24_dom.py 1440
python tests/cycle24_dom.py 390
python tests/cycle24_dom.py 320
python tests/cycle24_motion.py
python tests/cycle24_http.py
```
