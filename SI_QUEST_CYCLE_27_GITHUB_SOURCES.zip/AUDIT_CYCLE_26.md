# SI QUEST — Cycle 26 : accompagnement, réussite et traçabilité

**Date : 25 octobre 2026.** Point de départ réel : `SI_QUEST_CYCLE_25_20261025.zip`. Aucune refonte de l'accueil ou de la carte, aucun niveau supprimé, aucune publication GitHub. `index.html`, `src/home.js`, `src/catalog.js` et `src/physics.js` restent inchangés. La nouvelle couche pédagogique appelle le moteur physique existant.

## Modifications implémentées

1. **Célébration visuelle accessible** dans `play.html`, `src/game.js`, `src/style.css` : panneau trophée/étoiles, annonce textuelle de la réussite et niveau d'autonomie. Animation courte supprimée en mode `prefers-reduced-motion` ou lorsque « Limiter les animations » est activé. Pas de flash, de son ou de chronomètre pénalisant.
2. **Solution expliquée** dans `src/coaching.js` : calculs numériques dérivés du moteur `SIPhysics` pour les **7 types de niveaux**. Le bouton est invisible avant **3 indices ET 3 essais dans la série en cours**. La solution détaille formules, valeurs avec unités, contrôles et décision technique. La consultation est tracée ; la victoire qui suit ne peut pas recevoir trois étoiles, même après « Recommencer ».
3. **Diagnostic d'erreur** : bouton « Revoir mon erreur » après un essai non conforme ; il affiche la conséquence physique réellement calculée, la formule du modèle et les grandeurs observées. Le calcul intermédiaire faux et l'échec physique restent distincts.
4. **Carnet de mécanicien** : événements locaux effectivement produits (valeur réglée, unité, physique conforme/non conforme, calcul validé/non validé, indices, solution, étoiles, variante). Historique limité aux **40 derniers essais par niveau**, avec compteur total indépendant. Les données anciennes ne sont pas reconstituées. Import de sauvegarde : seuls les scores valides reconnus sont importés, jamais des événements d'essais invérifiables. Correction d'un bug : `saveWin` et `importData` préservent désormais l'historique local existant.
5. **Étoiles cohérentes** : 3 au premier essai sans aide, 2 après une correction légère, 1 après aide importante ou consultation de solution. Un redémarrage du niveau dans le même onglet **ne remet pas à zéro** les essais/indices utilisés pour calculer l'autonomie. Le record historique de base n'est pas confondu avec les défis de maîtrise.
6. **Défis de maîtrise à données modifiées** pour **`gear-01` et `moment-01` seulement**, après une victoire réelle : nouveau moteur 840 tr/min / 24 dents → cible 280 tr/min, réponse 72 dents ; nouvelle charge 360 N à 1,5 m et contrepoids 300 N → distance 1,8 m. La simulation, le calcul, les données visibles et la correction utilisent les nouveaux paramètres. Les défis de maîtrise **ne sont pas des niveaux indépendants supplémentaires** et ne gonflent pas le compteur de niveaux ni les badges.
7. **Confort de lecture sur l'écran de jeu** : agrandissement des textes, contraste renforcé, animations réduites, boutons de 44 px minimum, conservation locale des préférences, navigation clavier et focus des explications. Le lecteur d'écran peut consulter les alternatives textuelles existantes. Il ne s'agit pas d'une certification RGAA/WCAG.
8. **PWA** : cache versionné `siquest-cycle26-20261025`, nouveau fichier `src/coaching.js` inscrit au préchargement. Aucun changement de clé de sauvegarde ni de chemin GitHub Pages.

## Preuves effectivement exécutées

| Contrôle | Résultat observé | Preuve |
|---|---|---|
| Tests numériques Node, anciens et nouveaux | **81/81 réussis** ; 65 existants + 16 nouveaux | `tests/cycle26-node-tap.txt` |
| Calculs de solution | **7/7 solutions contrôlées par assertions sur le moteur physique et les contraintes** : engrenages, moments, MRUV/PFD, électrique, ressort, freinage, hydraulique | `tests/cycle26_coaching.test.cjs` |
| Variantes de maîtrise | **2/2** résolues et vérifiées avec paramètres différents | `tests/cycle26_coaching.test.cjs`, `tests/cycle26-browser-results.json` |
| Historique | Tests de création sans données fictives, aide, score, conservation, limite 40, import sécurisé | `tests/cycle26_journal.test.cjs` |
| Chromium DOM, 1440 × 900 | **7/7** niveaux : 3+3, explication, erreur, victoire accompagnée, carnet ; 2 variantes ; 0 erreur JS | `tests/cycle26-browser-results.json` |
| Chromium DOM, 390 × 844 | Mêmes parcours, aucun débordement horizontal | `tests/cycle26-browser-results.json`, captures `tests/cycle26-mobile-*.png` |
| Chromium DOM, 320 × 640 | Mêmes parcours, aucun débordement horizontal | `tests/cycle26-browser-results.json` |
| Anti-contournement « Recommencer » | **2 cas × 3 tailles d'écran** : indices ou essai raté restent comptabilisés dans l'autonomie | `tests/cycle26-browser-results.json` |
| Commandes d'accessibilité | **3 réglages × 3 tailles**, activation au clavier incluse | `tests/cycle26-browser-results.json` |
| Non-régression des 7 niveaux | Ancienne suite DOM du cycle 25 exécutée à **320, 390 et 1440 px**, succès sur les 7 parcours par taille | `tests/cycle26-regression-*.log` |
| Clavier, alternative textuelle et animation freinage | 3 parcours clavier + 2 états de freinage comparés à `SIPhysics.brakingAtTime` | `tests/cycle26-a11y-physics-run.log` |
| Liens, manifest, syntaxe JS | OK | `tests/cycle26-static.txt` |
| HTTP Python local, ressources du site | **13/13 HTTP 200**, manifeste, cache versionné et `coaching.js` présent | `tests/cycle26-http-results.json` |
| Navigation Chromium HTTP | **Bloquée** par `ERR_BLOCKED_BY_ADMINISTRATOR` : aucun verdict PWA navigateur | `tests/cycle26-browser-http-results.json` |

**Précision :** les tests DOM ont injecté les ressources localement dans Chromium headless. Ils ne démontrent pas la navigation HTTP réelle, l'installation du service worker, le hors-ligne ni la qualité sur appareils physiques. Le test HTTP Python est un contrôle de transport distinct. Aucun essai manuel NVDA, TalkBack, VoiceOver, Safari iOS, Chrome Android, Windows ou Mac n'a été effectué. Aucun contrôle complet zoom 400 %, WCAG 2.2 AA ou RGAA n'est revendiqué.

## Comptage et limites

- **17 univers catalogués**, dont **7** disposent d'un niveau jouable ; **10** n'en disposent pas.
- **7 sous-savoirs développés / 249** ; **242** non développés.
- **7 niveaux indépendants jouables et testés automatiquement / 996** ; **989** à développer. **+0** niveau indépendant au cycle 26, **+2 variantes de maîtrise** (non comptabilisées comme niveaux).
- **Aucun badge fictif** : les badges et étoiles de la carte continuent de lire les victoires réelles. Les variantes ne sont pas ajoutées au catalogue comme niveaux.
- **Pas encore développé** : variantes pour les 5 autres niveaux, tableaux de bord instrumentés, mode diagnostic à hypothèses et mesures, laboratoire libre, comparatif de solutions, missions finales avec OR. Ils sont dans la feuille de route et non déclarés jouables.
- **Mission finale** : cadrage existant conservé dans `SCENARIO_FINAL_CADRAGE.md`, pas de mission finale jouable.
- **Aucun déploiement GitHub**. Recette approfondie visée du **22 au 28 novembre 2026**, sans garantie prématurée de conformité.

## Reproduire

```sh
cd SI_QUEST
node --test tests/*.test.cjs
python tests/check_static.py
python tests/cycle26_dom.py
python tests/cycle26_http.py
python tests/cycle26_browser_http.py
python tests/cycle25_a11y_physics.py
python tests/cycle25_dom.py 320
python tests/cycle25_dom.py 390
python tests/cycle25_dom.py 1440
```

**Note :** les scripts historiques `cycle25_*` écrivent leurs propres fichiers de rapport historiques ; le registre de cycle 26 utilise les journaux `cycle26-regression-*` pour éviter de confondre les exécutions. Les fichiers historiques livrés dans cette archive ont été restaurés à l'identique depuis l'archive du cycle 25 après la non-régression.
