# SI QUEST — Cycle 23 : nouvelle mission Volt Start et recette indépendante
**Date : 25 octobre 2026.** Source : archive **SI_QUEST_CYCLE_22_20261024.zip** (`SHA-256 db927d41327ee5aa9898b500a97390d4b060c2f465f3528bdeb47bad62f65267`), extraite et enrichie, non reconstruite. Les fichiers historiques et les quatre niveaux précédents sont conservés. Aucun déploiement.

## 1. Contenu réellement produit

- **`electric-01`** dans **SI-08 Électricité et électrotechnique** : nouveau niveau indépendant « Volt Start — Remettre le démarreur en service ».
- **Modèle scientifique autonome** `SIPhysics.starterCable`, sans dépendance DOM : loi d'Ohm, résistance cuivre et contacts, tension au démarreur, pertes Joule et masse de cuivre.
- **Essais authentiques** : section saisie → calculs physiques → moteur animé si tension suffisante ; courant animé pendant l'essai ; échec pour tension, pertes thermiques, surmasse ou section non normalisée. Les erreurs n'interdisent pas l'essai.
- **Traçabilité** : résultats détaillés, unités, étapes de calcul et verdict accessible textuellement ; sauvegarde d'une victoire seulement après respect simultané des contraintes.
- **Badge « Pionnier SI »** : correctif de régression préventif ; sa règle « réussir les 4 niveaux pilotes » n'exige pas de réussir les niveaux ajoutés ensuite.
- **Accueil et carte** : pas de refonte, pas de nouvelle île ; nouvelle mission accessible dans la liste de missions et dans le catalogue SI-08. Cache SW incrémenté au cycle 23.

## 2. Hypothèses physiques et calculs indépendants

**Données :** batterie idéale 12,6 V ; courant d'essai constant 180 A ; longueur totale du chemin cuivre **aller + retour 4,0 m** ; résistivité cuivre à 20 °C 0,0175 Ω·mm²/m ; résistance de contacts 0,0005 Ω ; masse volumique cuivre 8960 kg/m³. Critères : tension au démarreur **≥ 10,5 V**, pertes électriques totales **≤ 200 W**, masse de cuivre **≤ 0,70 kg**, section normalisée parmi **6, 10, 16, 25, 35, 50 mm²**.

**Équations (SI) :** `R_Cu = ρ × L / S` avec ρ en Ω·mm²/m, L en m, S en mm² ; `R_tot = R_Cu + R_contacts` ; `ΔU = I × R_tot` ; `U_d = U_b − ΔU` ; `P_pertes = I² × R_tot` ; `m_Cu = ρ_m × L × S × 10⁻⁶` avec S en mm².

**Section gagnante 16 mm² :**

- `R_Cu = 0,0175 × 4 / 16 = 0,004375 Ω` ; `R_tot = 0,004875 Ω`.
- `ΔU = 180 × 0,004875 = 0,8775 V` ; `U_d = 12,6 − 0,8775 = 11,7225 V`.
- `P_Cu = 180² × 0,004375 = 141,75 W` ; `P_contacts = 180² × 0,0005 = 16,20 W` ; **`P_tot = 157,95 W`**.
- `m_Cu = 8960 × 4 × 16 × 10⁻⁶ = 0,57344 kg`.
- **Décision : conforme** ; les quatre conditions sont satisfaites.

**Essais négatifs indépendants :**

| Section | Tension | Pertes | Masse | Conséquence physique / métier |
|---|---:|---:|---:|---|
| 6 mm² | 10,41 V | 394,20 W | 0,21504 kg | Démarreur immobile ; tension et pertes non conformes |
| 10 mm² | 11,25 V | 243,00 W | 0,35840 kg | Rotation possible, échauffement excessif |
| 16 mm² | 11,7225 V | 157,95 W | 0,57344 kg | Mise en service autorisée |
| 25 mm² | 12,006 V | 106,92 W | 0,89600 kg | Rotation possible, surmasse |

**Validation croisée :** pour 25 mm², `R_tot = 0,0028 + 0,0005 = 0,0033 Ω`, donc `ΔU = 180 × 0,0033 = 0,594 V` et `U_d = 12,006 V` ; `P = 180 × 0,594 = 106,92 W`. Le test numérique indépendant vérifie également la relation `P = I × ΔU`.

**Limites :** batterie sans résistance interne ; courant de démarreur supposé constant même au blocage ; cuivre à 20 °C ; absence de transitoire thermique, d'inductance, de variation de courant avec la vitesse et de calcul de durée de tenue. Les pertes sont un critère de dimensionnement du scénario, pas un modèle thermique de câble. Le rotor n'est pas un modèle électromécanique de couple/vitesse.

## 3. Preuves exécutées

| Contrôle | Résultat | Fichier |
|---|---|---|
| Node `--test` | **45/45** | `tests/cycle23-node-tap.txt` |
| Vérification statique | **OK** | `tests/cycle23-static.txt` |
| Chromium DOM, 1440/390/320 px | **5/5 niveaux** : un essai faux puis un gagnant à chaque résolution, sans erreur JS | `tests/cycle23-browser-results.json` |
| Sauvegarde et badges | **5 victoires** conservées dans chaque contexte de test | `tests/cycle23-browser-results.json` |
| Contrôle d'animations | **5/5** canvas avec trames distinctes | `tests/cycle23-motion-results.json` |
| Contrôle ciblé du rotor | **2/2** : immobile à 6 mm², en rotation à 16 mm² | `tests/cycle23-rotor-results.json` |
| HTTP local | **12/12** ressources répondent 200 ; manifest et cache SW inspectés | `tests/cycle23-http-results.json` |
| Visuel mobile | Captures à **390 px**, avant essai et après réussite | `tests/cycle23-mobile-electric.png`, `tests/cycle23-mobile-electric-win.png` |

Les tests DOM utilisent l'injection HTML/JS/CSS sous Chromium, **car la politique de l'environnement bloque la navigation HTTP du navigateur**. Le serveur HTTP est testé séparément : il ne prouve ni l'installation de la PWA, ni le fonctionnement du service worker, ni le hors-ligne. Les captures ne remplacent pas une recette visuelle et tactile sur téléphone réel.

## 4. Décompte et réserves

- **17 univers catalogués** ; **5 sous-savoirs développés / 249** ; **5 niveaux jouables et testés automatiquement / 996** ; **1 nouveau niveau** ; **0 niveau fictif** ; **0 publication**.
- **991 niveaux** et **244 sous-savoirs** restent à développer. Les **5 niveaux** ne sont pas déclarés « réceptionnés sur matériel ».
- Aucun essai réel Android, iPhone, Windows, Mac, Safari, VoiceOver, TalkBack, NVDA ; pas de recette WCAG 2.2 AA / RGAA exhaustive ; PWA/offline non réceptionnés.
- L'accueil et la carte sont maintenus sans refonte jusqu'à la phase finale. L'intégration multitechnique finale (hydraulique + transmission + sécurité + décision métier) n'est pas encore réalisée.
- Objectif de recette approfondie : **22–28 novembre 2026**, sans clôture artificielle si des défauts persistent.
