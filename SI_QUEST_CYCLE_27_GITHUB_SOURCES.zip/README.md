# SI QUEST — Cycle 27 · 25 octobre 2026

Jeu pédagogique autonome en HTML/CSS/JavaScript. **Reprise de la livraison réelle du cycle 26**, sans refonte de l'accueil ni de la carte. Les quatre îles historiques restent les mêmes. Leurs étoiles affichées et noms accessibles reflètent maintenant les vrais records sauvegardés (correction d'un défaut de correspondance entre identifiants DOM et JavaScript).

**État réel : 17 univers catalogués, 10 sous-savoirs développés, 10 niveaux indépendants jouables et testés sous Chromium automatisé / 996 visés.** Il reste 239 sous-savoirs et 986 niveaux. Les compteurs de progression et les badges dépendent des réussites réellement enregistrées. Aucune mission finale fictive.

## Lancer localement

Décompresser, puis ouvrir `SI_QUEST/index.html` dans un navigateur moderne. Le jeu ne nécessite pas de backend. Pour tester les fonctionnalités PWA, utiliser HTTPS ou un serveur local :

```sh
cd SI_QUEST
python -m http.server 8765
```

Les chemins relatifs conviennent à un dépôt statique **GitHub Pages**, mais aucune publication n'a été effectuée.

## Cycle 27 : trois nouveaux moteurs physiques et niveaux indépendants

Trois nouveaux univers deviennent jouables : **pneumatique SI-07**, **thermique SI-12**, **métrologie SI-13**. Chaque mission possède son propre modèle physique, ses réglages, sa visualisation calculée, son contrôle d'une grandeur intermédiaire avec tolérance, ses conséquences en cas d'échec et sa décision métier. Les nouveaux niveaux ne sont pas des variantes de données. Les contrôles intermédiaires distinguent **résultat physique correct** et **calcul élève incorrect** ; les essais restent possibles sans pénalité de temps.

Le cycle 26 a introduit une célébration avec trophée et étoiles, un diagnostic de l'essai erroné, un **bouton de solution expliquée après 3 indices ET 3 essais**, et un **carnet de mécanicien local** (essais, aides, résultats et distinction entre conformité physique et justesse des calculs). Les aides consultées et essais réalisés ne peuvent pas être effacés du calcul des étoiles par un simple redémarrage dans le même onglet. La solution est calculée depuis le modèle physique pour chacun des dix niveaux.

Après une victoire, **deux défis de maîtrise à données différentes** sont disponibles sur Gear Forge et Méca Lab. Ils ne constituent pas de nouveaux niveaux indépendants et ne créent pas de badges fictifs. Sur l'écran de jeu, les préférences de taille de texte, contraste et réduction des animations sont enregistrées localement. Les autres améliorations demandées (tableaux de bord, diagnostic par hypothèses, laboratoire libre, comparaison, OR final) restent à développer.

**Preuves cycle 27 : 91/91 tests numériques Node réussis ; 10/10 niveaux vérifiés par parcours DOM automatisés sur 1440, 390 et 320 px ; 9 contrôles de trames physiques animées ; 9 parcours clavier des nouveaux niveaux ; 12 tests des tolérances de calcul ; 13/13 ressources HTTP.** La navigation HTTP dans Chromium a été bloquée par l'administrateur ; aucun essai PWA offline, appareil réel ou lecteur d'écran n'est revendiqué. Détails : `AUDIT_CYCLE_27.md`.

## Les dix niveaux réellement jouables

| Identifiant | Univers | Mission | Modèle scientifique |
|---|---|---|---|
| `gear-01` | SI-05 | Gear Forge | Rapport, vitesse, sens et couple d'engrenages |
| `moment-01` | SI-02 | Méca Lab | Moments et équilibre d'un bras |
| `gravity-01` | SI-03 | Gravity Run | PFD, accélération, distance et vitesse |
| `hydro-01` | SI-06 | Hydro Flow | Vérin, pression, effort et débit |
| `electric-01` | SI-08 | Volt Start | Résistance, chute de tension, pertes et masse de cuivre |
| `spring-01` | SI-11 | Spring Guard | Loi de Hooke, butée et énergie élastique |
| **`brake-01`** | **SI-04** | **Brake Point** | **Freinage, distance de réaction, adhérence et glissade** |
| **`pneumatic-01`** | **SI-07** | **Air Actuator** | **Équilibre de forces d’un vérin simple effet, ressort de rappel, course** |
| **`thermal-01`** | **SI-12** | **Thermo Control** | **Bilan énergétique, débit massique, élévation thermique, puissance de pompe** |
| **`metrology-01`** | **SI-13** | **Precision Gate** | **Incertitude composée, bande de garde, coût d’instrument** |

**Ajout du cycle 25 : Brake Point.** Télescopique de 6 000 kg à 4 m/s, délai de réaction de 0,80 s, ligne de sécurité à 7 m. L'élève choisit une commande de freinage en kN et calcule la distance d'arrêt. À 10 kN, la machine dépasse la ligne ; à 16 kN, elle s'arrête à **6,145 m** sans blocage ; à 22 kN, les roues se bloquent, et la force transmise est limitée par le coefficient de glissement. Les roues de l'animation s'arrêtent de tourner pendant la glissade. Les trajectoires sont calculées analytiquement à chaque instant.

La tolérance de **± 0,10 m** est réservée au calcul de l'élève ; la limite de sécurité de **7,0 m** et le seuil d'adhérence ne sont pas assouplis. Les essais incorrects restent possibles ; une bonne distance physique avec un calcul erroné ne donne pas d'étoile. Les hypothèses sont explicites : route horizontale, effort constant, sans ABS, sans transfert de charge ni effets thermiques. **Ce n'est pas un modèle constructeur ni une homologation de freinage.**

## Contrôles reproductibles

```sh
node --test tests/*.test.cjs
python tests/check_static.py
python tests/cycle27_dom.py
python tests/cycle27_animation.py
python tests/cycle27_keyboard.py
python tests/cycle27_arithmetic.py
python tests/cycle27_http.py

python tests/cycle27_regression_dom.py 1440
python tests/cycle27_regression_dom.py 390
python tests/cycle27_regression_dom.py 320
python tests/cycle25_motion.py
python tests/cycle25_a11y_physics.py

```

Les nouveaux rapports sont dans `tests/cycle27-*` et `AUDIT_CYCLE_27.md`. Les rapports historiques des cycles précédents restent archivés.

## Réserves

- **Tests DOM / animations** : Chromium headless, ressources injectées ; ne prouvent pas la navigation HTTP navigateur ni le comportement Safari.
- **HTTP** : test par client Python indépendant, transport de 13 ressources, manifeste et version de cache ; **ne prouve pas** installation PWA, cache offline ni service worker effectif.
- **Appareils physiques** : aucun essai réel sur Android, iPhone, Windows, Mac ou tablette. Aucun test manuel NVDA, TalkBack, VoiceOver ou WCAG/RGAA complet.
- **Animations** : les nouveaux niveaux disposent de trames vérifiées par comparaison aux résultats du moteur physique (9 échantillons), en plus des tests des anciens niveaux ; le nouveau freinage a également fait l'objet d'une comparaison numérique entre la trame et le moteur physique. Cela ne démontre pas la qualité de toutes les images ni de toutes les combinaisons de paramètres.
- **Mission intégratrice** : non développée ; cadrage dans `SCENARIO_FINAL_CADRAGE.md`. Recette approfondie visée du **22 au 28 novembre 2026**, avec corrections ultérieures si nécessaire.
- **GitHub** : aucun déploiement ou publication sans validation explicite.
