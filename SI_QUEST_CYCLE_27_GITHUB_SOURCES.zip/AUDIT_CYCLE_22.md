# SI QUEST — Cycle 22 · 24 octobre 2026

## Provenance et état réel

Source **reprise** : `SI_QUEST_CYCLE_21_CONSOLIDATION.zip` (cycle 21, conservé dans la conversation). Le cycle 01 reste l'origine du projet. Pas de refonte de l'accueil ou de la carte ; correction CSS ciblée de l'import JSON à 320 px.

**17 univers catalogués ; 4 sous-savoirs incarnés ; 4 niveaux jouables ; 4 mécaniques existantes ; 0 nouveau niveau créé.** Cibles non réalisées : 249 sous-savoirs / 996 niveaux. Aucun faux badge ni niveau ajouté.

## Corrections effectives

1. **Gravity Run** : le départ au repos sous la résistance statique ne crée plus une accélération négative fictive ; résistance effective égale à la traction jusqu'au seuil, distance et vitesse nulles. Une décélération depuis une vitesse initiale positive reste négative jusqu'à l'arrêt, sans marche arrière.
2. **Hydro Flow** : modèle de déplacement quasi statique lié au débit pompe (2 L/min), au rendement volumétrique (90 %), à la surface de piston et à la course (80 mm). Vitesse de tige `v = ηv Q / S`. Délai d'ouverture de vanne de 0,5 s. Charge immobile sous le seuil de force, sécurité verrouillée au-delà de 160 bar. L'arrondi de la pression minimale (±0,05 bar) reste distinct du seuil physique exact. Une pression de service conforme est acceptée même si elle diffère de la pression minimale calculée.
3. **Méca Lab** : rotation du bras pendant l'essai, calculée avec une inertie équivalente et un moment gravitaire variant avec `cos(θ)`, limitée par des butées ±15°. Réaction au pivot présentée comme valeur à l'équilibre uniquement.
4. **Gear Forge** : rotation animée à partir de la vitesse moteur, visualisée au ralenti ×12 ; le rapport des angles et le sens opposé suivent le nombre de dents. Pas d'animation permanente hors essai.
5. **Animation** : correction d'un vrai défaut intermittent : le timestamp `requestAnimationFrame` pouvait précéder légèrement `performance.now()`, produisant un temps négatif et une exception hydraulique. La progression est désormais bornée dans `[0,1]`. L'animation ne consomme plus de rafraîchissements en permanence hors essai.
6. **Pédagogie / accessibilité** : consignes spécifiques à chaque mission, champ de pression de service explicitement nommé, texte alternatif de résultat (`role=status`) après chaque essai, prise en compte de `prefers-reduced-motion`, contrôle clavier des îles et correction d'un débordement horizontal sur 320 px. Accueil et carte fonctionnellement inchangés.
7. **PWA** : identifiant de cache de service worker incrémenté (`siquest-cycle22-20261024`) pour invalider les anciennes ressources.

## Références numériques indépendantes

- Gear : `Z1=20`, `Z2=60`, `n1=900 tr/min`, `η=0,9`, `C1=9 N·m` → `n2=-300 tr/min`, `|C2|=24,3 N·m`.
- Moments : `450×2−300×3=0 N·m` à l'équilibre.
- Rover : `Fm=720 N`, `Fr=120 N`, `m=400 kg` → `a=1,5 m/s²`, `x(8)=48 m`, `v(8)=12 m/s`.
- Hydro : `S=0,0012566370614 m²`, `pmin=106,1032954 bar`, `F(106,1)=11999,6273 N` (**calcul arrondi accepté, levage physiquement impossible**). À `110 bar`, `F=12440,7069 N`, `v≈23,873 mm/s`, `x(4s)=80 mm` avec délai 0,5 s et butée de course. À `180 bar`, la sécurité bloque la course.

## Preuves exécutées

- `node --test tests/*.test.cjs` : **35 tests réussis / 35**, dont 14 nouveaux tests de physique cycle 22.
- `python tests/check_static.py` : références locales, icônes et syntaxe JS **OK**.
- `python tests/cycle22_dom.py` : Chromium headless par injection HTML/JS/CSS, **3 résolutions** (1440×900, 390×844, 320×640), **4/4 missions** testées avec essais incorrects et gagnants, sauvegarde locale, limites hydrauliques, labels, focus des îles et absence de débordement horizontal. Résultats dans `tests/cycle22-browser-results.json`.
- `python tests/cycle22_motion.py` : Chromium headless en animation activée, **4/4 canvas** avec changement réel d'image entre plusieurs frames. Résultats dans `tests/cycle22-motion-results.json`.
- `python tests/cycle22_http.py` : **12/12 ressources HTTP** servies (manifest, service worker, scripts, icônes) ; `tests/cycle22-http-results.json`.

## Réserves explicites

- La politique du navigateur de test bloque les navigations HTTP (`net::ERR_BLOCKED_BY_ADMINISTRATOR`). Les tests DOM et animation sont réalisés avec des ressources injectées, **pas** avec une page HTTP réellement naviguée. Les 12 tests HTTP ne démontrent pas l'installation PWA, l'activation du service worker ou le mode hors connexion.
- **Aucun essai matériel** Android, iPhone, Windows, Mac, Safari iOS, TalkBack, VoiceOver ou NVDA ; aucune réception RGAA/WCAG exhaustive.
- Les engrenages sont dessinés schématiquement, sans profil de denture normatif. Le rover utilise une résistance statique simplifiée. Le vérin impose une pression et un débit constants après ouverture de vanne : ni compressibilité ni transitoires de pression ni inertie de charge. Le bras utilise une inertie équivalente, sans amortissement ni analyse structurelle.
- **Mission finale de mise en service non développée.** Aucune publication GitHub ni déploiement effectué.

## Prochaine étape technique

Créer une **première mission intégratrice de mise en service** seulement après définition de sa chaîne de dépendances et de critères vérifiables (transmission + hydraulique + sécurité), puis ajouter un cinquième niveau réellement indépendant et tester le nouveau parcours. Maintenir l'accueil inchangé jusqu'à décision de refonte finale.
