# SI QUEST — Cycle 25 : Brake Point, exactitude du freinage et correction de la carte

**Date : 25 octobre 2026.** Reprise effective de `SI_QUEST_CYCLE_24_20261025.zip`, archive d'entrée SHA-256 **`1b91d71a4748b9cdf938ee04e8b3bc2d7ba1d51b49749602f694ab4474f28fab`**. Extraction dans un répertoire de travail propre ; aucun redémarrage du projet, aucune refonte de l'accueil, aucune publication GitHub.

## 1. Développement réellement effectué

- **Septième niveau indépendant** : `brake-01`, « Brake Point », dans **SI-04 — Dynamique et vibrations**. Mission de freinage d'un télescopique sur sol horizontal : force commandée, limite d'adhérence, glissade en cas de roues bloquées, distance de réaction, distance de freinage, distance totale et décision de mise en service. Essais erronés acceptés et visibles.
- **Moteur physique pur** : `SIPhysics.braking` et `SIPhysics.brakingAtTime` dans `src/physics.js`. Équations analytiques en unités SI, tests indépendants. Pendant la réaction : vitesse constante par hypothèse explicite. Pendant le freinage : décélération constante selon le PFD, sans vitesse négative après l'arrêt. Le blocage des roues remplace la force commandée par la force de frottement de glissement.
- **Animation calculée** : déplacement de l'avant de la machine lié à `x(t)`, rotation des roues liée à la distance parcourue ; en glissade, les roues restent bloquées tandis que la machine se déplace. La ligne rouge de sécurité est positionnée à 7 m selon la même échelle de dessin. Deux états d'animation ont été comparés au moteur physique à des instants mesurés.
- **Double vérification** : estimation de distance par l'élève acceptée à **± 0,10 m** (arrondis), mais **sans assouplir** la ligne de sécurité de **7,0 m** ni le seuil d'adhérence. Aucun score si le calcul est faux, même avec un arrêt physiquement conforme. L'essai reste possible en cas d'erreur.
- **Carte existante préservée** : correction du bug des étoiles des quatre îles historiques : le code cherchait des ID `map-*` absents du HTML ; il lit désormais les attributs `data-level` réels. Les étoiles et les noms accessibles reflètent les victoires réellement sauvegardées. Aucune île nouvelle, aucune pastille superposée, aucune refonte.
- **Ergonomie** : ordre de saisie cohérent (force → distance calculée → vérifier → essayer), commande et résultats accessibles au clavier, alternative textuelle lisible sur mobile (16 px). Correction d'une déformation du canvas sur écran étroit : ratio graphique conservé à **900:540**, sans `min-height` incompatible.
- **Cache PWA versionné** : `siquest-cycle25-20261025`. Aucun changement de clé de sauvegarde, aucun badge ajouté. Document de cadrage des futures missions intégratrices, explicitement **non jouable** : `SCENARIO_FINAL_CADRAGE.md`.

## 2. Vérification scientifique indépendante

Données du scénario : masse **6 000 kg**, vitesse initiale **4 m/s**, temps de réaction **0,80 s**, résistance au roulement **300 N**, coefficient d'adhérence statique **0,35**, coefficient de glissement **0,23**, pesanteur **9,81 m/s²**, limite **7,0 m**.

`F_adh,max = μ_s m g = 0,35 × 6000 × 9,81 = 20 601 N` ; `d_r = v₀ t_r = 4 × 0,8 = 3,2 m` ; `|a| = (F_f,eff + 300)/6000` ; `d_f = v₀²/(2|a|)` ; `d_arrêt = d_r + d_f`.

| Commande | Freinage effectif | Décélération | Distance de réaction | Distance de freinage | Distance totale | Verdict physique |
|---|---:|---:|---:|---:|---:|---|
| **10 kN** | 10 000 N | 1,7167 m/s² | 3,200 m | 4,660 m | **7,860 m** | Ligne dépassée |
| **16 kN** | 16 000 N | 2,7167 m/s² | 3,200 m | 2,945 m | **6,145 m** | Conforme, sans glissade |
| **22 kN** | 13 537,8 N | 2,3063 m/s² | 3,200 m | 3,469 m | **6,669 m** | Roues bloquées, refus de mise en service |

**Contrôles croisés** : à 16 kN, `m|a| = 6000 × 2,716666… = 16 300 N = F_f,eff + F_r`. La relation `v₀² = 2|a| d_f` donne `16 = 2 × 2,716666… × 2,944785…`. À 22 kN, `μ_glisse m g = 0,23 × 6000 × 9,81 = 13 537,8 N` et non 22 000 N. Les trajectoires sont continues à `t_r` et à l'arrêt ; aucune marche arrière.

**Hypothèses et limites** : modèle unidimensionnel sur sol horizontal, charge verticale égale à `mg`, coefficient constant, freinage uniforme, sans ABS, sans transfert dynamique de charge, sans suspension, sans pente, sans dérive latérale ni thermique. Les paramètres et seuils sont pédagogiques, pas des données constructeur ni des critères réglementaires d'homologation.

## 3. Preuves exécutées

| Type | Résultat réel | Fichier de preuve |
|---|---|---|
| Node `--test` (anciens + nouveaux tests) | **65/65 réussis** | `tests/cycle25-node-tap.txt` |
| Syntaxe JS, références et icônes | **OK** | `tests/cycle25-static.txt` |
| Chromium DOM injecté 1440 × 900 | **7/7 victoires, 7/7 essais faux**, zéro erreur JS | `tests/cycle25-browser-1440.json` |
| Chromium DOM injecté 390 × 844 | **7/7 victoires, 7/7 essais faux**, zéro erreur JS | `tests/cycle25-browser-390.json` |
| Chromium DOM injecté 320 × 640 | **7/7 victoires, 7/7 essais faux**, zéro erreur JS | `tests/cycle25-browser-320.json` |
| Cas additionnels | Glissade, dépassement, calcul de distance faux malgré arrêt sûr, arrêt sûr et calcul juste, hydraulique et ressort, sauvegarde 7/7 | Rapports DOM ci-dessus |
| Animation Chromium, sans réduction des mouvements | **7/7 niveaux** avec trames différentes | `tests/cycle25-motion-results.json` |
| Clavier seul + labels + statut + aspect ratio canvas | **3/3 résolutions** | `tests/cycle25-a11y-physics-results.json` |
| Animation Brake Point confrontée au moteur physique | **2/2 états** (16 et 22 kN), roues bloquées et non bloquées | `tests/cycle25-a11y-physics-results.json` |
| Transport HTTP local des ressources | **12/12 réponses HTTP 200** | `tests/cycle25-http-results.json` |
| Captures mobile simulé 390 px | Avant/après essai, inspection visuelle partielle | `tests/cycle25-mobile-brake.png`, `tests/cycle25-mobile-brake-win.png` |
| Traçabilité des fichiers | SHA-256 des fichiers modifiés + archive source | `tests/cycle25-provenance.json` |

**Distinction impérative des preuves :** les parcours DOM et les animations sont exécutés sous Chromium headless **avec ressources injectées**, car la navigation HTTP Chromium est bloquée par la politique de l'environnement. Le transport HTTP a été testé séparément par un client Python ; il ne valide **ni la navigation Chromium HTTP, ni le service worker, ni l'installation PWA, ni le fonctionnement hors connexion**. Aucun test sur appareils physiques Android/iPhone/Windows/Mac, aucune réception réelle au clavier matériel, avec TalkBack, VoiceOver ou NVDA. Aucune certification WCAG 2.2 AA ou RGAA. Les tests de trames ne démontrent pas la perfection de toutes les animations.

## 4. Décompte exact et suite

- **17 univers catalogués**, dont **7 ont au moins un niveau jouable** ; **10 univers** sans niveau jouable.
- **7 sous-savoirs développés / 249** ; **242** restent à développer.
- **7 niveaux indépendants jouables et testés automatiquement / 996** ; **989** restent à développer. **+1** niveau dans ce cycle ; **0** niveau factice ; **0** badge fictif ; **0** publication GitHub.
- Mission finale de mise en service **non jouable** ; cadrage documenté, développement et recette encore nécessaires.
- Recette approfondie visée du **22 au 28 novembre 2026**, avec corrections si nécessaire. La compatibilité sur matériel réel, l'accessibilité lecteurs d'écran et le fonctionnement PWA doivent être démontrés avant réception.

### Reproduire

```sh
cd SI_QUEST
node --test tests/*.test.cjs
python tests/check_static.py
python tests/cycle25_dom.py 1440
python tests/cycle25_dom.py 390
python tests/cycle25_dom.py 320
python tests/cycle25_motion.py
python tests/cycle25_a11y_physics.py
python tests/cycle25_http.py
```
